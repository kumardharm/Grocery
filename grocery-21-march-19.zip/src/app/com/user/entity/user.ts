export class user {
    
    password:string;
    id: string;
    role: string;
    last_login: number;
    addressid:string;
    
    name : string;
    email:string;
    mobile: number;
    state:string;
    city:string;
    zip:number;
    country:string;
    landmark:string;
    address:string;
    addresstype:string;
}