export class address_class {
user_id: string;
name:string;
address:string;
address_type:string;
state:string;
city:string;
zip:number;
country:string;
landmark:string;
mobile:number;
email:string;
}