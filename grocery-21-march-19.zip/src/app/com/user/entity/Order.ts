export class order {
    order_id:string;
	invoice_number:string;
	shipping_address:string;
	billing_address:string;
	sgst:number;
	cgst:number;
	product_id:string;
	sub_id:number;
	product_name:string;
	product_qty:number;
	product_price:number;
	total_amt:number;
	discount:number;
	user_id:string;
	payment_mode:string;
	
} 

	